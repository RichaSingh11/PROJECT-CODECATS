#include<iostream>
#include<conio.h>
#include<stdio.h>
#include<string.h>
#include<fstream>
using namespace std;
class shopping
{


   // public: bool isLoggedIn;
	private:	struct items
				{
					int item_id;
					string item_name;
					int mrp;
					int dis;
					int gst;
					float buy_price;
				};
				
				
	public:void linepattern()
		{
			for(int i=0;i<3;i++)
				{
					for(int j=0;j<57;j++)
						{		
							cout<<"*";
						}
					cout<<endl;
				}
		}
									
				
	public: void display()
	{
				linepattern();
				cout<<"***"<<"                                                   "<<"***"<<endl;
				cout<<"***"<<"        WELCOME TO RISHA'S SHOPPING CENTRE         "<<"***"<<endl;
				cout<<"***"<<"               ------------------                  "<<"***"<<endl;               
				cout<<"***"<<"               PAY LESS,SHOP MORE                  "<<"***"<<endl;
				cout<<"***"<<"                                                   "<<"***"<<endl;
				linepattern();
				cout << "Press any key to continue...";
				getch();
	}
	
			
	public:void menu()
	{
		int ch;
		system("cls");		
		do{
				linepattern();						
				cout<<"***"<<"                                                   "<<"***"<<endl;
				cout<<"***"<<"       1.MEN                                       "<<"***"<<endl;
				cout<<"***"<<"       2.WOMEN                                     "<<"***"<<endl;
				cout<<"***"<<"       3.SIGN UP                                   "<<"***"<<endl;               
				cout<<"***"<<"       4.LOG IN                                    "<<"***"<<endl;
				cout<<"***"<<"       5.EXIT	                              "<<"***"<<endl;
				cout<<"***"<<"       	                                      "<<"***"<<endl;
				cout<<"***"<<"     Customer Care : 1860-893-3333                 "<<"***"<<endl;
				linepattern();
								
						cout<<"  Please Enter Your Choice : ";
						cin>>ch;
						cout<<endl;								
							switch(ch)
								{
									case 1:discountMENU('m');
											break;		
									case 2:discountMENU('m');
											break;
									case 3:signup();
											break;
									case 4:login();
											break;
									case 5:cout<<"  Please select from the option given in the menu ,THANKYOU !!! "<<endl;
											break;
															
								}
								system("cls");
							}
										
				while(ch!=5);
			}
			
	
		public:void  signup()
		{
			string userId,password,rid,rpass,name,address,email;
			long mobileno;
			
			cout<<"     Enter the name :   \n";
			cin>>name;
			cout<<"     Enter the address :   \n";
			cin>>address;
			cout<<"     Enter the Mobile Number :   \n";
			cin>>mobileno;
			cout<<"     Enter the Username :       \n";
			cin>>userId;
			cout<<"     Enter the Email :        \n";
			cin>>email;
			cout<<"     Enter the Password :   \n";
			cin>>password;
			
			ofstream f2;
			ifstream read;
			string file = userId + ".txt";
			read.open(file.c_str());
			if(read)
			{
				cout<<"Username already exists!";
				read.close();
			}
			else{
				
					f2.open(file.c_str());
					f2<< userId<<endl<< email<<endl<< password<<endl;
					ofstream f3("name.txt", ios::app);
					f3 << name<<endl;
					ofstream f4("address.txt", ios::app);
					f4 << address<<endl;
					ofstream f5("mobileno.txt", ios::app);
					f5 << mobileno<<endl;
				
				    system("cls");
			
			        cout<<"\n     Signed In Successfully !     \n";	
		  		}	
		}
		
		public:void login()
		{
			int count;
			string userId, password, id, pass;
			cout<<"\n   Please enter the username and password : "<<endl;
			cout<<"\n   Please enter Username :   \n";
			cin>>userId;
			cout<<"\n   Please enter Password :   \n";
			cin>>password;
		
			ifstream f;
			string file = userId + ".txt";
			f.open(file.c_str());
			while(f>>id>>pass)
			{
				if(id==userId && pass==password)
				 count++;
			}
					f.close();
					
				if(count==1)
				{
					cout<<userId<<"\n   Logged In Successfully !   \n";
				
				}
				else
					cout<<"Please check your username and password again ! \n";
			}
		
	public : void discountMENU(char gender) {
				
	system("cls");
		linepattern();						
				cout<<"***"<<"                                                   "<<"***"<<endl;
				cout<<"***"<<"       1.DISCOUNT                                  "<<"***"<<endl;
				cout<<"***"<<"       2.NON-DISCOUNT                              "<<"***"<<endl;
				cout<<"***"<<"       3.BACK                                      "<<"***"<<endl;              
				cout<<"***"<<"       	                                      "<<"***"<<endl;
				cout<<"***"<<"     Customer Care : 1860-893-3333                 "<<"***"<<endl;
				linepattern();
								
	int choice;
	cout<<"Enter your choice : ";
	cin >> choice;
	switch( choice ) {
		case 1 : 
			if( gender == 'm')
				menDiscountShop();
			else 
				womenDiscountShop();
			break;
		case 2 : 
			if( gender == 'm')
				menNonDiscountShop();
			else 
				womenNonDiscountShop();
			break;
		case 3 : 
			menu();
			break;
		default : 
			cout << "Enter Correct choice : ";
	}
}

			
	public:void menDiscountShop()
	{
	    /*
	    system("cls");
		        linepattern();						
				cout<<"***"<<"                                                   "<<"***"<<endl;
				cout<<"***"<<"       SHOPPING ITEM                               "<<"***"<<endl;      	                                      "<<"***"<<endl;
				cout<<"***"<<"     Customer Care : 1860-893-3333                 "<<"***"<<endl;
				linepattern();
								
	ifstream file("menDiscount.txt");
	int ItemID,Price,Discount,GST,BuyPrice;
	string ItemName;
	if( file.is_open() ) {
		cout << "Item ID \t Item Name \t         Price \t\t Discount \t GST \t Buy Price" << endl;
		string line;
		while( getline(file,line) ) {
			file >> ItemID 
				>> ItemName 
				>> Price 
				>> Discount 
				>> GST 
				>> BuyPrice;
			cout <<"   " << ItemID  << "\t\t  " << ItemName << "\t\t" << "Rs."<<Price << "\t\t   " << Discount<<" %" << "\t\t " << GST<<" %" << "\t  " << "Rs."<<BuyPrice << endl;
		}
		if(this -> isloggedIN) {
			int id;
			cout << "Add items to cart : \n";
			cout << "Enter Item ID : ";
			cin >> id;
			file.seekg(0,ios::beg);
			int i = 0;
			while( getline(file,line) ) {
				file >> ItemID 
					>> ItemName 
					>> Price 
					>> Discount 
					>> GST 
					>> BuyPrice; 
				if( ( id % 100) == i++ )
					addToCart(ItemID,ItemName,BuyPrice);
				cout<<i <<"   ";
			}
			cout << "Press any key if you want to continue shopping ... ";
		} else {
			cout<<"Please Login to add Items into cart !! \n";
			cout << "Press any key to continue ... \n";
		}
		file.close();
		getch();
		
	} else {
		cout<<"No Items ! \n";
	}
}

		
	}
	
	*/
			
	public:void womenDiscountShop()
	{
		
	}
	
	public:void menNonDiscountShop()
	{
		
	}
	
	public:void womenNonDiscountShop()
	{
		
	}

	public:void addToCart()
	{
	    
	}
		
	
};
int main()
{
	shopping ob;	
				
	ob.display();
	ob.menu();
	
				
	return 0;
}

